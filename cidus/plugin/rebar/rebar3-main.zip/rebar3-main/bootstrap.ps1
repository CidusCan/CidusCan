& escript.exe bootstrap @args
